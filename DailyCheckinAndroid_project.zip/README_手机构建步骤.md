# 每日打卡助手 Android 项目（手机可操作的云端构建版）

这个项目把打卡页面打包进 Android 应用，安装后可从桌面图标打开，不需要每次手动打开浏览器。打卡数据使用 WebView 的本地存储，通常保存在此应用内。

## 重要说明
- 这是 Android 源码项目，不是已编译 APK；需要通过 GitHub Actions 云端构建生成 APK。
- 构建产物是 debug APK，仅适合个人测试和自用，不是正式发布版。
- 安装未知来源应用时，只允许你信任的来源；不要关闭手机整体安全防护。
- 卸载应用或清除应用数据可能删除打卡记录。不要在应用里存放敏感信息。
- 当前项目未配置提醒通知、云同步或账号系统。

## 只用手机的大致步骤
1. 登录 GitHub 并新建一个公开或私有仓库，例如 `daily-checkin-android`。
2. 解压本 ZIP。需要把里面的项目文件夹内容上传到仓库根目录，必须保留 `.github/workflows/build-apk.yml` 这个隐藏目录及其文件。
3. 上传完成后进入仓库的 **Actions** 标签页，允许启用 Actions；选择 **Build Android APK** 工作流并点击 **Run workflow**（如果 push 到 main，也会自动构建）。
4. 等构建显示绿色成功后，打开该次运行页面底部的 **Artifacts**，下载 `DailyCheckin-debug-apk`。
5. 在手机文件管理器里解压下载的 artifact ZIP，找到 `app-debug.apk`，点击安装。若系统提示，按需允许文件管理器或浏览器“安装未知应用”，安装后可在应用列表找到“每日打卡助手”，再将图标添加到桌面。

## 手机操作时容易遇到的问题
- GitHub 网页上传文件不太适合整目录。务必确认 `.github/workflows/build-apk.yml` 也上传成功，否则 Actions 不会出现构建任务。
- 若下载到的只是项目 ZIP，不是 `app-debug.apk`，说明还没完成云端构建。
- 如果 GitHub Actions 构建失败，请把失败日志截图发来再排查。
